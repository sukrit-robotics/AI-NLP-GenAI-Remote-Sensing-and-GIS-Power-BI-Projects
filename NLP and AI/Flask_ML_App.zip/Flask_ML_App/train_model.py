import os
import re
import pickle
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

# 1. टेक्स्ट क्लीनिंग के लिए ज़रूरी डेटा डाउनलोड करना
print("NLTK Stopwords डाउनलोड हो रहे हैं...")
nltk.download('stopwords')

# 2. 'Models' नाम का नया फ़ोल्डर बनाना
if not os.path.exists("Models"):
    os.makedirs("Models")
    print("'Models' नाम का फ़ोल्डर बना दिया गया है.")

# 3. डमी डेटा तैयार करना (ताकि बिना एरर के तुरंत मॉडल बन सके)
print("सैंपल डेटा तैयार किया जा रहा है...")
data = {
    'verified_reviews': [
        'I love this alexa echo it is amazing', 
        'bad product stopped working', 
        'very good and useful speaker', 
        'horrible experience not happy'
    ],
    'feedback': [1, 0, 1, 0]  # 1 = Positive, 0 = Negative
}
df = pd.DataFrame(data)

# 4. Text Processing (re और nltk की मदद से टेक्स्ट साफ करना)
print("टेक्स्ट प्रोसेसिंग शुरू हो रही है...")
ps = PorterStemmer()
corpus = []

for i in range(len(df)):
    review = re.sub('[^a-zA-Z]', ' ', df['verified_reviews'][i])
    review = review.lower().split()
    review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
    review = ' '.join(review)
    corpus.append(review)

# 5. CountVectorizer और StandardScaler को फिट करना
cv = CountVectorizer(max_features=1000)
X_cv = cv.fit_transform(corpus).toarray()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_cv)

# 6. ML Model (Decision Tree) को ट्रेन करना
model = DecisionTreeClassifier()
model.fit(X_scaled, df['feedback'])

# 7. तीनों ज़रूरी फ़ाइलों को 'Models' फ़ोल्डर में सेव करना
print("फ़ाइलों को सेव (Pickle) किया जा रहा है...")
with open("Models/countVectorizer.pkl", "wb") as f:
    pickle.dump(cv, f)

with open("Models/scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

with open("Models/model_dt.pkl", "wb") as f:
    pickle.dump(model, f)

print("\nबधाई हो! मशीन लर्निंग मॉडल की तीनों (.pkl) फ़ाइलें सफलतापूर्वक 'Models' फ़ोल्डर में बन गई हैं!")

