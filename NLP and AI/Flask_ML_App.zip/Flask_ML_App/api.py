from flask import Flask, request, jsonify, send_file, render_template
import re
from io import BytesIO

# nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import matplotlib.pyplot as plt
import pandas as pd
import pickle
import base64

STOPWORDS = set(stopwords.words("english"))

app = Flask(__name__)


@app.route("/test", methods=["GET"])
def test():
    return "Test request received successfully. Service is running."


@app.route("/", methods=["GET", "POST"])
def home():
    return render_template("landing.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        # मॉडल्स को सही नाम से लोड करना
        predictor = pickle.load(open("Models/model_dt.pkl", "rb"))
        scaler = pickle.load(open("Models/scaler.pkl", "rb"))
        cv = pickle.load(open("Models/countVectorizer.pkl", "rb"))
        
        corpus = []
        graph_b64 = ""

        # 1. अगर यूज़र ने केवल टेक्स्ट बॉक्स में टाइप किया है
        if "text" in request.form and request.form["text"].strip() != "":
            raw_text = request.form["text"]
            review = re.sub('[^a-zA-Z]', ' ', raw_text)
            review = review.lower().split()
            review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
            corpus.append(' '.join(review))

        # 2. अगर यूज़र ने CSV फ़ाइल अपलोड की है
        elif "file" in request.files and request.files["file"].filename != '':
            file = request.files["file"]
            data = pd.read_csv(file)
            
            if 'verified_reviews' not in data.columns:
                return jsonify({"status": "Error", "message": "CSV file missing 'verified_reviews' column"})
                
            for i in range(len(data)):
                review = re.sub('[^a-zA-Z]', ' ', str(data['verified_reviews'][i]))
                review = review.lower().split()
                review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
                corpus.append(' '.join(review))
            
            # सिर्फ CSV अपलोड होने पर ग्राफ जनरेट करने का प्रयास करना
            try:
                # प्रेडिक्शन से पहले ग्राफ फंक्शन को कॉल करें (डेटा को प्रोसेस करने के बाद)
                graph_b64 = get_distribution_graph(data) 
            except Exception as graph_error:
                print("Graph Error:", str(graph_error))

        else:
            return jsonify({"status": "Error", "message": "No input text or file provided"})

        # डेटा ट्रांसफ़ॉर्मेशन और प्रेडिक्शन
        if len(corpus) > 0:
            X_cv = cv.transform(corpus).toarray()
            X_scaled = scaler.transform(X_cv)
            predictions = predictor.predict(X_scaled)
            
            # प्रेडिक्शन को टेक्स्ट में बदलना (Positive/Negative)
            pred_labels = ["Positive" if p == 1 else "Negative" for p in predictions]
            
            return jsonify({
                "status": "Success", 
                "predictions": pred_labels,
                "graph_base64": graph_b64,
                "message": "Sentiments predicted successfully!"
            })
        else:
            return jsonify({"status": "Error", "message": "Could not process text"})
                
    except Exception as e:
        # एरर को टर्मिनल में प्रिंट करना ताकि समस्या दिखे
        print("Backend Error:", str(e))
        return jsonify({"status": "Error", "message": str(e)})

           


def single_prediction(predictor, scaler, cv, text_input):
    corpus = []
    stemmer = PorterStemmer()
    review = re.sub("[^a-zA-Z]", " ", text_input)
    review = review.lower().split()
    review = [stemmer.stem(word) for word in review if not word in STOPWORDS]
    review = " ".join(review)
    corpus.append(review)
    X_prediction = cv.transform(corpus).toarray()
    X_prediction_scl = scaler.transform(X_prediction)
    y_predictions = predictor.predict_proba(X_prediction_scl)
    y_predictions = y_predictions.argmax(axis=1)[0]

    return "Positive" if y_predictions == 1 else "Negative"


def bulk_prediction(predictor, scaler, cv, data):
    corpus = []
    stemmer = PorterStemmer()
    for i in range(0, data.shape[0]):
        review = re.sub("[^a-zA-Z]", " ", data.iloc[i]["Sentence"])
        review = review.lower().split()
        review = [stemmer.stem(word) for word in review if not word in STOPWORDS]
        review = " ".join(review)
        corpus.append(review)

    X_prediction = cv.transform(corpus).toarray()
    X_prediction_scl = scaler.transform(X_prediction)
    y_predictions = predictor.predict_proba(X_prediction_scl)
    y_predictions = y_predictions.argmax(axis=1)
    y_predictions = list(map(sentiment_mapping, y_predictions))

    data["Predicted sentiment"] = y_predictions
    predictions_csv = BytesIO()

    data.to_csv(predictions_csv, index=False)
    predictions_csv.seek(0)

    graph = get_distribution_graph(data)

    return predictions_csv, graph


def get_distribution_graph(data):
    fig = plt.figure(figsize=(5, 5))
    colors = ("green", "red")
    wp = {"linewidth": 1, "edgecolor": "black"}
    tags = data["Predicted sentiment"].value_counts()
    explode = (0.01, 0.01)

    tags.plot(
        kind="pie",
        autopct="%1.1f%%",
        shadow=True,
        colors=colors,
        startangle=90,
        wedgeprops=wp,
        explode=explode,
        title="Sentiment Distribution",
        xlabel="",
        ylabel="",
    )

    graph = BytesIO()
    plt.savefig(graph, format="png")
    plt.close()

    return graph


def sentiment_mapping(x):
    if x == 1:
        return "Positive"
    else:
        return "Negative"


if __name__ == "__main__":
    app.run(port=5000, debug=True, use_reloader=False)
    


    
    
    
    

