import openai
from config import OPENAI_API_KEY

openai.api_key = OPENAI_API_KEY

def Chatbot(input):
    messages = [
        {"role": "system", "content": "You are an AI specialized in Power BI."},
        {"role": "user", "content": input}
    ]
    
    chat = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages
    )
    
    reply = chat.choices[0].message.content
    return reply


