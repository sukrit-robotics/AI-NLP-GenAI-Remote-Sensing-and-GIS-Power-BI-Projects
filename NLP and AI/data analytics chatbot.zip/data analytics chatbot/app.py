from flask import Flask, render_template, request, jsonify
from chat import Chatbot

app = Flask(__name__, template_folder='templates')


@app.route("/")
def hello():
    return render_template('chat.html')


@app.route("/ask", methods=['POST'])
def ask():
    message = str(request.form['messageText'])
    
    bot_response = chatbot(message)
    # print(bot_response)
    return jsonify({'status': 'OK', 'answer': bot_response})


if __name__ == "__main__":
    app.run()
    

